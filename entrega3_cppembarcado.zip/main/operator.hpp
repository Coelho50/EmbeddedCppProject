
#ifndef   OPERATOR_HPP
#define   OPERATOR_HPP

#include <string>

//converts the number of a node to string and appends the data in that node
std::string operator%(int, std::string);

#endif